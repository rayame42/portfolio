# Portfólio · Rayane Santos

Tráfego pago, marketing e dados.

Site: https://rayame42.github.io/portfolio/

## Estrutura

```
index.html            página
favicon.ico           ícone da aba do navegador
previa_social.png     imagem que aparece ao compartilhar o link (WhatsApp, LinkedIn)
img/                  foto, ícones e prints de conversas
audio/                áudios dos depoimentos
certificados/         imagens dos certificados
.nojekyll             avisa o GitHub Pages para publicar os arquivos como estão
```

## Publicar no GitHub Pages

1. Crie um repositório público chamado `portfolio` na conta `rayame42`.
2. Envie todos os arquivos desta pasta para a raiz do repositório (Add file → Upload files).
3. Em Settings → Pages, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
4. Em 1 ou 2 minutos o site fica no ar em https://rayame42.github.io/portfolio/.

Para trocar uma imagem, envie um arquivo novo com o mesmo nome na mesma pasta.
